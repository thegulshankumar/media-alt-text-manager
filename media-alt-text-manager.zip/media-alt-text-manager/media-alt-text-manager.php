<?php
/**
 * Plugin Name: Media Alt Text Manager
 * Plugin URI: https://wordpress.org/plugins/media-alt-text-manager/
 * Description: Adds a sortable Alt Text column to the media library, allowing easy management of alt text for media items.
 * Version: 1.1
 * Author: Gulshan Kumar
 * Author URI: https://www.gulshankumar.net
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: media-alt-text-manager
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Add a custom column to the media library
function matm_add_edit_alt_text_column($columns) {
    if (current_user_can('edit_posts')) {
        $columns['alt_text_edit'] = esc_html__('Alt Text', 'media-alt-text-manager');
    }
    return $columns;
}
add_filter('manage_media_columns', 'matm_add_edit_alt_text_column');

// Populate the custom column with alt text and edit links
function matm_display_edit_alt_text_column($column_name, $post_id) {
    if ($column_name === 'alt_text_edit' && current_user_can('edit_post', $post_id)) {
        $alt_text = get_post_meta($post_id, '_wp_attachment_image_alt', true);
        if (empty($alt_text)) {
            $edit_link = get_edit_post_link($post_id);
            echo '<a href="' . esc_url($edit_link) . '">' . esc_html__('Set alt text', 'media-alt-text-manager') . '</a>';
        } else {
            echo esc_html($alt_text);
        }
    }
}
add_action('manage_media_custom_column', 'matm_display_edit_alt_text_column', 10, 2);

// Make the custom column sortable
function matm_sortable_alt_text_status_column($columns) {
    if (current_user_can('edit_posts')) {
        $columns['alt_text_edit'] = 'alt_text_status';
    }
    return $columns;
}
add_filter('manage_upload_sortable_columns', 'matm_sortable_alt_text_status_column');

// Define the sorting logic for the custom column
function matm_sort_media_by_alt_text_status($query) {
    if (!is_admin() || !$query->is_main_query() || !current_user_can('edit_posts')) {
        return;
    }
    $orderby = $query->get('orderby');
    if ('alt_text_status' === $orderby) {
        $order = strtoupper($query->get('order', 'ASC'));
        // Meta query to filter images without alt text
        $query->set('meta_query', array(
            'relation' => 'OR',
            array(
                'key' => '_wp_attachment_image_alt',
                'compare' => 'NOT EXISTS', // Images without alt text
            ),
            array(
                'key' => '_wp_attachment_image_alt',
                'value' => '',
                'compare' => '=', // Images with empty alt text
            ),
        ));
        
        // Set orderby to prioritize meta_query results and then by date
        if ($order === 'ASC') {
            // Order images without alt text first and then by post date ascending
            $query->set('orderby', array(
                'meta_value' => 'ASC', // This will ensure images without alt text come first
                'post_date' => 'ASC', // Older images first
            ));
        } else {
            // Order images without alt text first and then by post date descending
            $query->set('orderby', array(
                'meta_value' => 'ASC', // This will ensure images without alt text come first
                'post_date' => 'DESC', // Newer images first
            ));
        }
    }
}
add_action('pre_get_posts', 'matm_sort_media_by_alt_text_status');

// Sanitize and save alt text with nonce verification
function matm_save_alt_text($post_id) {
    // Check if our nonce is set and verify it
    if (!isset($_POST['matm_alt_text_nonce']) || !wp_verify_nonce($_POST['matm_alt_text_nonce'], 'matm_save_alt_text_' . $post_id)) {
        return;
    }

    // Check if the current user has permission to edit the post
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Check if it's not an autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Save the alt text if it's set
    if (isset($_POST['_wp_attachment_image_alt'])) {
        $alt_text = wp_kses_post(wp_unslash($_POST['_wp_attachment_image_alt']));
        update_post_meta($post_id, '_wp_attachment_image_alt', $alt_text);
    }
}
add_action('edit_attachment', 'matm_save_alt_text');

// Add nonce field to the attachment edit form
function matm_add_nonce_to_attachment_form() {
    global $post;
    if ($post && $post->post_type === 'attachment') {
        wp_nonce_field('matm_save_alt_text_' . $post->ID, 'matm_alt_text_nonce');
    }
}
add_action('edit_form_after_title', 'matm_add_nonce_to_attachment_form');