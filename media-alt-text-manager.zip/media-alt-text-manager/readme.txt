=== Media Alt Text Manager ===
Contributors: thegulshankumar
Donate link: https://ko-fi.com/gulshan
Tags: accessibility, alt text, media library, seo, image optimization
Requires at least: 5.0
Requires PHP: 7.2
Tested up to: 6.6.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily manage alt text for media items directly from the WordPress media library, improving accessibility and SEO.

== Description ==

The **Media Alt Text Manager** plugin enhances the WordPress media library by adding a sortable 'Alt Text' column. This feature simplifies managing alternative text for images, thereby improving your site's accessibility and SEO.

=== Key Features ===
* **Alt Text Column**: Adds a new column to the media library displaying the alt text for each image.
* **Sorting by Alt Text Status**: Enables sorting of media items based on their alt text status.
* **Quick Edit Links**: Provides direct links to edit alt text for images missing it.
* **Enhanced Workflow**: Streamlines the process of ensuring all images have appropriate alt text.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/media-alt-text-manager` directory, or install the plugin through the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to your Media Library to start using the plugin.

== Frequently Asked Questions ==

=== Who can use this plugin? ===
Users with the capability to edit posts (typically editors and administrators) can view and interact with the alt text management features provided by this plugin.

=== Is this plugin compatible with my theme? ===
Yes, this plugin is compatible with most WordPress themes as it modifies functionality only within the media library in the admin area.

== Screenshots ==

1. Media library with the new Alt Text column.

== Changelog ==

=== 1.0 ===
* Initial release of the Media Alt Text Manager plugin.

== Upgrade Notice ==

=== 1.0 ===
Initial release of the Media Alt Text Manager plugin.